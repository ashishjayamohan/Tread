# Tread
A python data science package for people who just want to get on with it.
This repository is currently under development but aspires to have these features within the next month:
* Summation
* Averaging
* Skew
* Standard Deviation
* Element Stray
Other features will be added to the package in due time.
Made by: Ashish Jayamohan
